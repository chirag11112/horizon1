<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class User_inquiry.
 */
class User_inquiry extends Model
{
    
}
