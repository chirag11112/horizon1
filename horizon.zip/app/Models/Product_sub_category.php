<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Product_sub_category.
 */
class Product_sub_category extends Model
{
    
}
