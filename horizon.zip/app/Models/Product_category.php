<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Product_category.
 */
class Product_category extends Model
{
    
}
