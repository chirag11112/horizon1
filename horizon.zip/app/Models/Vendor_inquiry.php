<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class Vendor_inquiry.
 */
class Vendor_inquiry extends Model
{
    
}
