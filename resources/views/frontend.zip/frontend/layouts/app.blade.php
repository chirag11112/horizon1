@include('frontend.layouts.header')
@yield('content')
@include('frontend.layouts.footer')
